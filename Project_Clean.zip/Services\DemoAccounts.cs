namespace SmartStudyHub.Services;

public sealed record Account(string Email, string Password, string Name);

public static class DemoAccounts
{
    public static Account Default { get; } = new("demo@smartstudyhub.io", "demo1234", "Demo Student");

    private static readonly Account[] All = [Default];

    public static Account? FindByEmail(string? email)
    {
        var wanted = email?.Trim();
        return All.FirstOrDefault(a => string.Equals(a.Email, wanted, StringComparison.OrdinalIgnoreCase));
    }

    public static Account? Validate(string? email, string? password)
    {
        var account = FindByEmail(email);
        return account is not null && string.Equals(account.Password, password, StringComparison.Ordinal)
            ? account
            : null;
    }
}