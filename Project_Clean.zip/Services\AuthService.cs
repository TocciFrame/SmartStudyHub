using Microsoft.JSInterop;

namespace SmartStudyHub.Services;

public sealed record UserSession(string Email, string Name);

public sealed class AuthService(IJSRuntime js)
{
    private const string StorageKey = "smartstudyhub.session";

    private Task? _initialization;

    public UserSession? CurrentUser { get; private set; }

    public bool IsAuthenticated => CurrentUser is not null;

    public Task InitializeAsync() => _initialization ??= RestoreAsync();

    public async Task<bool> LoginAsync(string? email, string? password)
    {
        var account = DemoAccounts.Validate(email, password);
        if (account is null)
        {
            return false;
        }

        CurrentUser = new UserSession(account.Email, account.Name);
        _initialization = Task.CompletedTask;   // nothing left to restore
        await TryStorageAsync(() => js.InvokeVoidAsync("localStorage.setItem", StorageKey, account.Email).AsTask());
        return true;
    }

    public async Task LogoutAsync()
    {
        CurrentUser = null;
        _initialization = Task.CompletedTask;
        await TryStorageAsync(() => js.InvokeVoidAsync("localStorage.removeItem", StorageKey).AsTask());
    }

    private async Task RestoreAsync()
    {
        try
        {
            var email = await js.InvokeAsync<string?>("localStorage.getItem", StorageKey);
            var account = DemoAccounts.FindByEmail(email);
            CurrentUser = account is null ? null : new UserSession(account.Email, account.Name);
        }
        catch (JSException)
        {
            CurrentUser = null; 
        }
    }

    private static async Task TryStorageAsync(Func<Task> action)
    {
        try { await action(); }
        catch (JSException) { /* storage unavailable: the in-memory session still works */ }
    }
}